import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { VideoProject, PipelineJob, PipelineEvent } from '../src/types.js';
const ROOT=path.resolve(process.cwd(),'storage'); const PROJECTS=path.join(ROOT,'projects'); const JOBS=path.join(ROOT,'jobs');
for(const d of [ROOT,PROJECTS,JOBS]) fs.mkdirSync(d,{recursive:true});
export function assertSafeId(id:string){if(!/^[A-Za-z0-9_-]{1,100}$/.test(id)) throw new Error('Invalid identifier');}
export function getProjectDir(id:string){assertSafeId(id); const d=path.join(PROJECTS,id); fs.mkdirSync(d,{recursive:true}); for(const sub of ['scenes','audio','music','sfx','captions','thumbnails','renders','temp','versions']) fs.mkdirSync(path.join(d,sub),{recursive:true}); return d;}
function atomicWrite(file:string,data:string){const tmp=`${file}.${process.pid}.${crypto.randomUUID()}.tmp`; fs.writeFileSync(tmp,data,'utf8'); fs.renameSync(tmp,file);}
export function saveProject(p:VideoProject){const d=getProjectDir(p.id); p.updatedAt=new Date().toISOString(); atomicWrite(path.join(d,'project.json'),JSON.stringify(p,null,2));}
export function getProject(id:string){try{assertSafeId(id);}catch{return null} const f=path.join(PROJECTS,id,'project.json'); if(!fs.existsSync(f)) return null; try{const p=JSON.parse(fs.readFileSync(f,'utf8')) as VideoProject; p.scenes=Array.isArray(p.scenes)?p.scenes:[]; p.renderLogs=p.renderLogs||[]; p.currentStage=p.currentStage||'topic'; p.status=p.status||'draft'; return p}catch(e){console.error(e);return null}}
export function listJobs(){return fs.readdirSync(JOBS).filter(f=>f.endsWith('.json')&&!f.endsWith('.events.ndjson')).map(f=>getJob(f.slice(0,-5))).filter((j):j is PipelineJob=>!!j);}
export function getAllProjects(){return fs.readdirSync(PROJECTS,{withFileTypes:true}).filter(e=>e.isDirectory()).map(e=>getProject(e.name)).filter((p):p is VideoProject=>!!p).sort((a,b)=>Date.parse(b.createdAt)-Date.parse(a.createdAt));}
export function deleteProject(id:string){assertSafeId(id); const d=path.join(PROJECTS,id); if(!fs.existsSync(d)) return false; fs.rmSync(d,{recursive:true,force:true}); return true;}
export function saveJob(j:PipelineJob){j.updatedAt=new Date().toISOString(); atomicWrite(path.join(JOBS,`${j.id}.json`),JSON.stringify(j,null,2));}
export function getJob(id:string){if(!/^[A-Za-z0-9_-]+$/.test(id))return null; const f=path.join(JOBS,`${id}.json`); if(!fs.existsSync(f))return null; try{return JSON.parse(fs.readFileSync(f,'utf8')) as PipelineJob}catch{return null}}
export function saveEvent(e:PipelineEvent){const f=path.join(JOBS,`${e.jobId}.events.ndjson`); fs.appendFileSync(f,JSON.stringify(e)+'\n','utf8');}
export function readEvents(id:string){const f=path.join(JOBS,`${id}.events.ndjson`); if(!fs.existsSync(f))return []; return fs.readFileSync(f,'utf8').split('\n').filter(Boolean).map(x=>JSON.parse(x) as PipelineEvent);}
export function cleanupTempFiles(maxAgeMs=24*60*60*1000){const cutoff=Date.now()-maxAgeMs; if(!fs.existsSync(PROJECTS))return; for(const e of fs.readdirSync(PROJECTS,{withFileTypes:true})){if(!e.isDirectory())continue; const t=path.join(PROJECTS,e.name,'temp'); if(!fs.existsSync(t))continue; for(const f of fs.readdirSync(t)){const p=path.join(t,f); try{if(fs.statSync(p).mtimeMs<cutoff)fs.rmSync(p,{recursive:true,force:true})}catch{}}}}
export { ROOT as STORAGE_ROOT };
