export type VideoAspectRatio = '16:9' | '9:16';
export type VideoTone = 'Engaging & Fast-Paced'|'Informative & Educational'|'Dramatic & Storytelling'|'Humorous & Entertaining'|'Mysterious & Documentary'|'Motivational & Inspiring';
export type VisualStyle = 'Cinematic Photorealism'|'Digital Concept Art'|'Anime & Manga'|'3D Pixar Style'|'Dark Atmospheric Noir'|'Minimalist Motion Vector';
export type VoiceName = 'Kore'|'Puck'|'Fenrir'|'Charon'|'Zephyr';
export type PipelineStage = 'topic'|'research'|'story'|'script'|'scenes'|'visuals'|'voiceover'|'audio'|'timeline'|'captions'|'thumbnail'|'render'|'qa'|'assembly'|'completed';
export type EntityStatus = 'pending'|'generating'|'ready'|'failed'|'fallback'|'needs_review';
export interface Scene { id:string; sceneNumber:number; narration:string; visualDescription:string; imagePrompt:string; estimatedDurationSeconds:number; actualDurationSeconds?:number; onScreenText?:string; imageUrl?:string; audioUrl?:string; isGeneratingImage?:boolean; isGeneratingAudio?:boolean; status:EntityStatus; errorMessage?:string; motionPreset?:MotionPreset; transition?:TransitionPreset; }
export type MotionPreset='ZOOM_IN'|'ZOOM_OUT'|'PAN_LEFT'|'PAN_RIGHT'|'PAN_UP'|'PAN_DOWN'|'PARALLAX'|'PUSH'|'FADE'|'SLIDE';
export type TransitionPreset='CUT'|'FADE'|'DISSOLVE'|'SLIDE';
export interface AudioTrack { id:string; type:'narration'|'music'|'sfx'; assetUrl:string; startTime:number; duration:number; volume:number; fadeIn:number; fadeOut:number; ducking?:number; }
export interface TimelineItem { id:string; sceneId:string; start:number; duration:number; type:'shot'|'audio'|'caption'|'transition'; assetUrl?:string; text?:string; }
export interface Timeline { duration:number; items:TimelineItem[]; chapters:{time:string;title:string}[]; }
export interface ResearchResult { keyFacts:string[]; dates:string[]; names:string[]; numbers:string[]; importantEvents:string[]; claims:string[]; sources:string[]; uncertaintyFlags:string[]; openQuestions:string[]; status:'unreviewed'|'approved'|'needs_review'; }
export interface YouTubeMetadata { title:string; description:string; tags:string[]; category:string; chapters:{time:string;title:string}[]; hashtags?:string[]; pinnedComment?:string; playlistSuggestion?:string; videoFilename?:string; }
export interface PipelineEvent { id:string; jobId:string; projectId:string; type:string; stage:PipelineStage; message:string; progressPercent:number; timestamp:string; data?:unknown; }
export interface PipelineJob { id:string; projectId:string; status:'queued'|'running'|'paused'|'cancelled'|'failed'|'completed'; currentStage:PipelineStage; progressPercent:number; completedStages:PipelineStage[]; errorMessage?:string; createdAt:string; updatedAt:string; }
export interface ChannelProfile { id:string; name:string; logo?:string; brandColors?:string[]; typography?:string; defaultLanguage?:string; defaultVoice?:VoiceName; captionStyle?:string; defaultMusicStyle?:string; intro?:string; outro?:string; cta?:string; youtubeMetadataSettings?:Record<string,unknown>; }
export interface VideoProject { id:string; title:string; topic:string; aspectRatio:VideoAspectRatio; tone:VideoTone; visualStyle:VisualStyle; voice:VoiceName; targetDurationMinutes:number; createdAt:string; updatedAt:string; currentStage:PipelineStage; status:'draft'|'generating'|'ready'|'error'|'completed'; errorMessage?:string; script?:string; youtubeMetadata?:YouTubeMetadata; research?:ResearchResult; scenes:Scene[]; timeline?:Timeline; audioTracks?:AudioTrack[]; finalVideoUrl?:string; thumbnailUrl?:string; totalDurationSeconds?:number; renderProgress?:number; renderLogs?:string[]; }
export interface SystemStatus { hasGeminiKey:boolean; hasFfmpeg:boolean; storagePath:string; activeProjectsCount:number; activeJobsCount:number; models:{text:string;image:string;tts:string}; }
export interface PipelineProgressEvent { stage:PipelineStage; status:'started'|'progress'|'completed'|'error'; message:string; progressPercent:number; data?:unknown; }
